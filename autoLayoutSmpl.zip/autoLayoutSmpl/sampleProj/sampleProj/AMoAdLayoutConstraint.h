//
//  AMoAdLayoutConstraint.h
//  AMoAd
//
//  Created by AMoAd on 2015/06/12.
//

#import <UIKit/UIKit.h>

@interface AMoAdLayoutConstraint : NSLayoutConstraint

@end
